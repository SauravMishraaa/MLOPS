

def test_generic():
    a=5
    b=10
    assert a!=b